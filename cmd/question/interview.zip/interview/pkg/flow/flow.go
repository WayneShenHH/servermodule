package flow

type Flow struct {
	Message string
}
